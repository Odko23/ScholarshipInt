const resultContainer = document.getElementById("result");
const searchBtn = document.getElementById("search-button");
const searchInput = document.getElementById("search-input");
const searchContainer = document.querySelector(".search-box");

const universities = [
    {
        name: "University of Sydney",
        location: "Sydney, Australia",
        image: "university-sydney.png",
        link: "https://scholarshiproar.com/university-of-sydney-international-scholarships/"
    },
    {
        name: "University of Melbourne",
        location: "Melbourne, Australia",
        image: "university-melbourne.jpg",
        link: "https://scholarships.unimelb.edu.au/awards/melbourne-international-undergraduate-scholarship"
    },
    {
        name: "University of Queensland",
        location: "Brisbane, Australia",
        image: "university-queensland.jpg",
        link: "https://study.uq.edu.au/global?studentType=international&gad=1&gclid=CjwKCAjw-IWkBhBTEiwA2exyO-3GY9S4hMW9H9XyX4Wnnv8wP-FNPCUoeRewiPKq9NmM8B3nhcx97xoCynwQAvD_BwE"
    }
];

searchBtn.addEventListener("click", searchUniversity);
searchInput.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {
        e.preventDefault();
        searchUniversity();
    }
});


function searchUniversity() {
    const userInput = searchInput.value.trim();
    if (!userInput) {
        resultContainer.innerHTML = `<h3>Input Field Cannot Be Empty</h3>`;
        return;
    }
   
    const searchResult = universities.filter(university => university.location.toLowerCase().includes(userInput.toLowerCase()));
    if (searchResult.length === 0) {
        resultContainer.innerHTML = `<h3>No University Found, Please Try Again!</h3>`;
        return;
    }
   
    let universitiesHtml = "";
    searchResult.forEach(university => {
        universitiesHtml += `
            <div class="university">
                <h2>${university.name}</h2>
                <h4>${university.location}</h4>
                <a href="${university.link}" target="_blank">
                    <img src="${university.image}" alt="${university.name}" />
                </a>
                <a class="university-link" href="${university.link}" target="_blank">Scholarship Information</a>
            </div>
        `;
    });
    resultContainer.innerHTML = universitiesHtml;
    searchContainer.style.opacity = '0';
    searchContainer.style.display = 'none';
}

