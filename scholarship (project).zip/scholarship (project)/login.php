<?php 

session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			
			$query = "select * from users where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: index.php");
						die;
					}
				}
			}
			
			echo "wrong username or password!";
		}else
		{
			echo "wrong username or password!";
		}
	}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		body {
			background-image: url('day.jpg');
			background-size: cover;
			background-position: center;
		}

		#text {
			height: 40px;
			border-radius: 5px;
			padding: 8px;
			border: solid thin #aaa;
			width: 100%;
			font-size: 18px;
		}

		#button {
			padding: 12px;
			width: 150px;
			color: white;
			background-color: #FFC857;
			border: none;
			font-size: 20px;
		}

		#box {
			margin: auto;
			width: 300px;
			height: 300px;
			padding: 50px;
			text-align: center;
			border-radius: 50%;
			background-color: rgba(255, 255, 255, 0.8); 

		#box h2 {
			font-size: 36px;
			margin: 10px;
			color: black; 
		}

		#box a {
			font-size: 24px;
			color: black; 
			text-decoration: none;
		}
	</style>
</head>
<body>
	<div id="box">
		<form method="post">
			<h2>Login</h2>
			<input id="text" type="text" name="user_name" placeholder="Username"><br><br>
			<input id="text" type="password" name="password" placeholder="Password"><br><br>
			<input id="button" type="submit" value="Login"><br><br>
			<a href="signup.php">Click to Signup</a><br><br>
		</form>
	</div>
</body>
</html>




