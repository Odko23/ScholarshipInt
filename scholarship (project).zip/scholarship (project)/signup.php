<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);

			header("Location: login.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	<style type="text/css">
		body {
			background-image: url('night.jpg');
			background-size: cover;
			background-position: center;
		}

		#text {
			height: 40px;
			border-radius: 5px;
			padding: 8px;
			border: solid thin #aaa;
			width: 100%;
			font-size: 18px;
		}

		#button {
			padding: 12px;
			width: 150px;
			color: white;
			background-color: #FFC857;
			border: none;
			font-size: 20px;
		}

		#box {
			background-color: rgba(255, 255, 255, 0.8);
			margin: auto;
			width: 400px;
			height: 400px;
			border-radius: 50%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
		}

		#box h2 {
			font-size: 36px;
			margin: 10px;
			color: black;
		}

		#box a {
			font-size: 24px;
			color: black;
			text-decoration: none;
		}
	</style>
</head>
<body>
	<div id="box">
		<form method="post">
			<h2>Signup</h2>
			<input id="text" type="text" name="user_name" placeholder="Username"><br><br>
			<input id="text" type="password" name="password" placeholder="Password"><br><br>
			<input id="button" type="submit" value="Signup"><br><br>
			<a href="login.php">Click to Login</a><br><br>
		</form>
	</div>
</body>
</html>

